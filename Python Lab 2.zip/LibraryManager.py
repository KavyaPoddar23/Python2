# LibraryManager.py

# Initialize the library dictionary
library = {}

def add_book(isbn, title, author, publisher, volume, year, isbn_number):
    """Add a book to the library."""
    if isbn in library:
        raise ValueError(f"Book with ISBN {isbn} already exists.")
    library[isbn] = {
        'title': title,
        'author': author,
        'publisher': publisher,
        'volume': volume,
        'year': year,
        'isbn_number': isbn_number
    }

def remove_book(isbn):
    """Remove a book from the library by its ISBN."""
    if isbn in library:
        del library[isbn]
    else:
        raise KeyError(f"Book with ISBN {isbn} not found.")

def retrieve_book(isbn):
    """Retrieve and display the details of a book using its ISBN."""
    if isbn in library:
        return library[isbn]
    else:
        raise KeyError(f"Book with ISBN {isbn} not found.")

def search_books(query):
    """Search for books by title or author."""
    results = []
    for book in library.values():
        if query.lower() in book['title'].lower() or query.lower() in book['author'].lower():
            results.append(book)
    return results

def list_books():
    """List all books currently in the library."""
    return list(library.values())

def update_book(isbn, title=None, author=None, publisher=None, volume=None, year=None, isbn_number=None):
    """Update the details of an existing book."""
    if isbn in library:
        if title is not None:
            library[isbn]['title'] = title
        if author is not None:
            library[isbn]['author'] = author
        if publisher is not None:
            library[isbn]['publisher'] = publisher
        if volume is not None:
            library[isbn]['volume'] = volume
        if year is not None:
            library[isbn]['year'] = year
        if isbn_number is not None:
            library[isbn]['isbn_number'] = isbn_number
    else:
        raise KeyError(f"Book with ISBN {isbn} not found.")

def check_availability(isbn):
    """Check if a book is available in the library by its ISBN."""
    return isbn in library
