# main.py

import LibraryManager as lm

# Sample books
books = [
    {'isbn': '9780134685991', 'title': 'Operating Systems: Three Easy Pieces', 'author': 'Remzi H. Arpaci-Dusseau', 'publisher': 'Arpaci-Dusseau Books', 'volume': '1', 'year': 2020, 'isbn_number': '9780134685991'},
    {'isbn': '9780135166307', 'title': 'Data Structures and Algorithm Analysis in Python', 'author': 'Clifford A. Shaffer', 'publisher': 'Pearson', 'volume': '1', 'year': 2021, 'isbn_number': '9780135166307'},
    {'isbn': '9781801075704', 'title': 'Machine Learning with Python Cookbook', 'author': 'Chris Albon', 'publisher': 'O\'Reilly Media', 'volume': '1', 'year': 2022, 'isbn_number': '9781801075704'},
]

# Adding books to the library
for book in books:
    lm.add_book(book['isbn'], book['title'], book['author'], book['publisher'], book['volume'], book['year'], book['isbn_number'])

print("All books in the library:")
print(lm.list_books())

print("\nRetrieving details of a book:")
print(lm.retrieve_book('9780134685991'))

print("\nSearching for books by title 'Machine Learning':")
print(lm.search_books('Machine Learning'))

print("\nChecking availability of book with ISBN '9780135166307':")
print(lm.check_availability('9780135166307'))

print("\nUpdating book details:")
lm.update_book('9780135166307', title='Data Structures and Algorithm Analysis in Python (Updated)')
print(lm.retrieve_book('9780135166307'))

print("\nRemoving a book:")
lm.remove_book('9781801075704')
print(lm.list_books())
