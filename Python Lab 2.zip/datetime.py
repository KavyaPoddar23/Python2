from datetime import datetime, timedelta

# Generate a list of dictionaries 
def generate_weather_data(start_date, end_date):
    date_list = []
    current_date = start_date
    while current_date <= end_date:
        date_list.append({
            'date': current_date.strftime('%Y-%m-%d'),
        })
        current_date += timedelta(days=1)
    return date_list

# Define start and end dates
start_date = datetime(2024, 8, 1)
end_date = datetime(2024, 7, 10)

# Generate weather data
weather_data = generate_weather_data(start_date, end_date)

# Function to find the highest and lowest temperatures
def find_highest_lowest_temps(data):
    max_temp = float("-inf")
    min_temp = float("inf")
    for entry in data:
        if entry['max_temp'] > max_temp:
            max_temp = entry['max_temp']
        if entry['min_temp'] < min_temp:
            min_temp = entry['min_temp']
    return max_temp, min_temp

# Function to determine the number of days with temperatures above 30°C
def count_days_above_30(data):
    count = 0
    for entry in data:
        if entry['max_temp'] > 30:
            count += 1
    return count

# Function to compute the average humidity
def average_humidity(data):
    total_humidity = 0
    count = 0
    for entry in data:
        total_humidity += entry['humidity']
        count += 1
    return total_humidity / count if count > 0 else 0

# Demonstrate the functionality
if __name__ == "__main__":
    weather_data = generate_weather_data(start_date, end_date)

    # Find highest and lowest temperatures
    highest_temp, lowest_temp = find_highest_lowest_temps(weather_data)
    print(f"Highest Temperature: {highest_temp}°C")
    print(f"Lowest Temperature: {lowest_temp}°C")

    # Count days with temperatures above 30°C
    days_above_30 = count_days_above_30(weather_data)
    print(f"Number of Days with Temperature Above 30°C: {days_above_30}")

    # Compute average humidity
    avg_humidity = average_humidity(weather_data)
    print(f"Average Humidity: {avg_humidity:.2f}%")
