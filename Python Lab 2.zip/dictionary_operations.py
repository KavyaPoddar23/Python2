# dictionary_operations.py

def merging_dict(*args):
    """Merge multiple dictionaries into one."""
    merged_dict = {}
    for d in args:
        merged_dict.update(d)
    return merged_dict

def find_common_keys(*args):
    """Find common keys across multiple dictionaries."""
    if not args:
        return set()
    
    common_keys = set(args[0].keys())
    for d in args[1:]:
        common_keys.intersection_update(d.keys())
    return common_keys

def invert_dict(d):
    """Invert a dictionary, swapping keys and values."""
    inverted_dict = {}
    for key, value in d.items():
        if value in inverted_dict:
            if isinstance(inverted_dict[value], list):
                inverted_dict[value].append(key)
            else:
                inverted_dict[value] = [inverted_dict[value], key]
        else:
            inverted_dict[value] = key
    return inverted_dict

def find_common_key_value_pairs(*args):
    """Find common key-value pairs across multiple dictionaries."""
    if not args:
        return {}
    
    common_pairs = set(args[0].items())
    for d in args[1:]:
        common_pairs.intersection_update(d.items())
    return dict(common_pairs)

# Example usage
if __name__ == "__main__":
    dict1 = {'a': 1, 'b': 2, 'c': 3}
    dict2 = {'b': 2, 'c': 3, 'd': 4}
    dict3 = {'c': 3, 'd': 4, 'e': 5}

    print("Merging Dictionaries:")
    print(merging_dict(dict1, dict2, dict3))

    print("\nFinding Common Keys:")
    print(find_common_keys(dict1, dict2, dict3))

    print("\nInverting a Dictionary:")
    sample_dict = {'a': 1, 'b': 2, 'c': 1}
    print(invert_dict(sample_dict))

    print("\nFinding Common Key-Value Pairs:")
    print(find_common_key_value_pairs(dict1, dict2, dict3))
