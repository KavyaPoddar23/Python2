# main_SetOperations.py

import module_SetOperations as mso

# Define example sets
set1 = {1, 2, 3}
set2 = {3, 4, 5}

# Demonstrate the functions
print("Initial Sets:")
print("Set 1:", set1)
print("Set 2:", set2)

# a. Add an element to a set
mso.add_element(set1, 4)
print("\nAfter adding 4 to Set 1:", set1)

# b. Remove an element from a set
mso.remove_element(set1, 2)
print("After removing 2 from Set 1:", set1)

# c. Union and intersection of two sets
print("\nUnion of Set 1 and Set 2:", mso.union_sets(set1, set2))
print("Intersection of Set 1 and Set 2:", mso.intersection_sets(set1, set2))

# d. Difference between two sets
print("\nDifference Set 1 - Set 2:", mso.difference_sets(set1, set2))

# e. Check if Set 1 is a subset of Set 2
print("\nIs Set 1 a subset of Set 2?", mso.is_subset(set1, set2))

# f. Find the length of a set without using len()
print("\nLength of Set 1:", mso.set_length(set1))

# g. Symmetric difference between two sets
print("\nSymmetric difference of Set 1 and Set 2:", mso.symmetric_difference_sets(set1, set2))

# h. Compute the power set of a given set
print("\nPower set of Set 1:", mso.power_set(set1))

# i. Get all unique subsets of a given set
print("\nUnique subsets of Set 1:", mso.unique_subsets(set1))
