# main_ListOperations.py

import module_ListFunction as mlf

# Create lists using Python comprehension
list1 = [i for i in range(1, 11)]  # List from 1 to 10
list2 = [i * i for i in range(5)]  # List of squares: [0, 1, 4, 9, 16]
list3 = [x for x in range(10, 0, -1)]  # List from 10 to 1 in reverse

# Demonstrate module functions
print("List 1:", list1)
print("Max of List 1:", mlf.find_max(list1))
print("Min of List 1:", mlf.find_min(list1))
print("Sum of List 1:", mlf.calculate_sum(list1))
print("Average of List 1:", mlf.compute_average(list1))
print("Median of List 1:", mlf.find_median(list1))

print("\nList 2:", list2)
print("Max of List 2:", mlf.find_max(list2))
print("Min of List 2:", mlf.find_min(list2))
print("Sum of List 2:", mlf.calculate_sum(list2))
print("Average of List 2:", mlf.compute_average(list2))
print("Median of List 2:", mlf.find_median(list2))

print("\nList 3:", list3)
print("Max of List 3:", mlf.find_max(list3))
print("Min of List 3:", mlf.find_min(list3))
print("Sum of List 3:", mlf.calculate_sum(list3))
print("Average of List 3:", mlf.compute_average(list3))
print("Median of List 3:", mlf.find_median(list3))
