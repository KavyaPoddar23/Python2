# module_SetOperations.py

def add_element(s, elem):
    """Add an element to a set, ensuring no errors if the element is already present."""
    s.add(elem)

def remove_element(s, elem):
    """Remove an element from a set, ensuring no errors if the element is not present."""
    s.discard(elem) 

def union_sets(s1, s2):
    """Return the union of two sets, handling empty sets correctly."""
    return s1.union(s2)

def intersection_sets(s1, s2):
    """Return the intersection of two sets, handling empty sets correctly."""
    return s1.intersection(s2)

def difference_sets(s1, s2):
    """Return the difference S1 - S2, handling empty sets correctly."""
    return s1.difference(s2)

def is_subset(s1, s2):
    """Check if set S1 is a subset of set S2, handling empty sets correctly."""
    return s1.issubset(s2)

def set_length(s):
    """Find the length of a set without using the len() function."""
    count = 0
    for _ in s:
        count += 1
    return count

def symmetric_difference_sets(s1, s2):
    """Compute the symmetric difference of two sets."""
    return s1.symmetric_difference(s2)

def power_set(s):
    """Compute the power set of a given set."""
    power_set_list = [[]]
    for elem in s:
        power_set_list.extend([subset + [elem] for subset in power_set_list])
    return [set(subset) for subset in power_set_list]

def unique_subsets(s):
    """Get all unique subsets of a given set."""
    return power_set(s)  
